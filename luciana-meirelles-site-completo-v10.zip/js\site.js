/* =====================================================================
   Luciana Meirelles Advocacia · JS mínimo (sem bibliotecas)
   0. Abertura com o logo (computador)
   1. Menu em gaveta acessível (celular)
   2. Sombra no cabeçalho ao rolar
   3. Animações suaves ao entrar na tela (IntersectionObserver)
   3b. Banners da capa (3 banners, pausa, indicadores)
   4. Limpeza de parâmetros de rastreio da URL (utm_*, fbclid, gclid)
   ===================================================================== */
(function () {
  "use strict";
  var html = document.documentElement;

  /* ---------- 0. Abertura: o logo desenha no centro e voa para o cabeçalho ----------
     A decisão de mostrar (só computador, só na Início, 1x por visita) é do script inline do <head>. */
  var introRodou = false;
  function iniciarIntro() {
    if (introRodou || !html.classList.contains("abrindo")) return;
    var cortina = document.querySelector(".abertura");
    var logo = document.querySelector(".abertura__logo");
    var carga = document.querySelector(".abertura__carga");
    var alvo = document.querySelector(".topo .marca");
    if (!cortina || !logo || !alvo) return;
    introRodou = true;
    var ESCALA = innerWidth < 600 ? 1.35 : 1.8;
    // mesma posição do CSS (centro da tela), mas medida a partir do logo do cabeçalho
    var b = alvo.getBoundingClientRect();
    var dx = innerWidth / 2 - b.left - (b.width * ESCALA) / 2;
    var dy = innerHeight / 2 - b.top - (b.height * ESCALA) / 2;
    logo.style.left = b.left + "px";
    logo.style.top = b.top + "px";
    logo.style.width = b.width + "px";
    logo.style.transformOrigin = "0 0";
    logo.style.transform = "translate(" + dx + "px," + dy + "px) scale(" + ESCALA + ")";

    var foi = false;
    var voar = function () {
      if (foi) return;
      foi = true;
      if (carga) carga.classList.add("sai");
      logo.style.transition = "transform .9s cubic-bezier(.76,0,.24,1)";
      logo.style.transform = "none";
      setTimeout(function () {
        cortina.classList.add("sobe");
        html.classList.remove("abrindo-trava");
        document.dispatchEvent(new Event("lm:intro-fim"));
      }, 60);
      setTimeout(function () { html.classList.remove("abrindo"); }, 980);
    };
    var pronto = function () { setTimeout(voar, Math.max(0, 1400 - performance.now())); };
    if (document.readyState === "complete") pronto(); else window.addEventListener("load", pronto);
    setTimeout(voar, 2800);
  }
  iniciarIntro();
  window.LMIntro = iniciarIntro; // usado pela pré-visualização em arquivo único

  /* ---------- 1. Menu em gaveta ---------- */
  var botao = document.querySelector(".menu-botao");
  var menu = document.getElementById("menu-principal");
  var desktop = window.matchMedia("(min-width: 1000px)");

  function abrir(estado) {
    if (!botao || !menu) return;
    botao.setAttribute("aria-expanded", String(estado));
    botao.setAttribute("aria-label", estado ? "Fechar menu" : "Abrir menu");
    menu.classList.toggle("aberto", estado);
    document.body.classList.toggle("menu-aberto", estado);
    if (estado) {
      var primeiro = menu.querySelector("a");
      if (primeiro) primeiro.focus();
    }
  }

  if (botao && menu) {
    botao.addEventListener("click", function () {
      abrir(botao.getAttribute("aria-expanded") !== "true");
    });
    // Fecha com Esc e devolve o foco ao botão
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && menu.classList.contains("aberto")) {
        abrir(false);
        botao.focus();
      }
    });
    // Fecha ao escolher um link (inclusive âncoras da mesma página)
    menu.addEventListener("click", function (e) {
      if (e.target.closest("a")) abrir(false);
    });
    // Mantém o foco dentro da gaveta enquanto aberta
    menu.addEventListener("keydown", function (e) {
      if (e.key !== "Tab" || desktop.matches) return;
      var focaveis = menu.querySelectorAll("a, button");
      var ini = focaveis[0], fim = focaveis[focaveis.length - 1];
      if (e.shiftKey && document.activeElement === ini) { e.preventDefault(); botao.focus(); }
      else if (!e.shiftKey && document.activeElement === fim) { e.preventDefault(); botao.focus(); }
    });
    // Ao passar para o desktop, garante o menu "fechado" no estado mobile
    desktop.addEventListener("change", function () { abrir(false); });
  }

  /* ---------- 2. Cabeçalho com sombra ao rolar ---------- */
  var topo = document.querySelector(".topo");
  if (topo) {
    var marcar = function () { topo.classList.toggle("rolou", window.scrollY > 8); };
    marcar();
    window.addEventListener("scroll", marcar, { passive: true });
  }

  /* ---------- 3. Revelar ao rolar ---------- */
  // elementos recortados (clip-path) não "aparecem" para o observador; por isso
  // observamos o elemento pai e marcamos o filho como visível
  var alvos = new Map();
  var obs = "IntersectionObserver" in window ? new IntersectionObserver(function (entradas) {
    entradas.forEach(function (en) {
      if (!en.isIntersecting) return;
      var lista = alvos.get(en.target) || [];
      alvos.delete(en.target);
      obs.unobserve(en.target);
      // dois quadros de espera garantem que o estado inicial foi desenhado antes da animação
      requestAnimationFrame(function () { requestAnimationFrame(function () {
        lista.forEach(function (el) { el.classList.add("visivel"); });
      }); });
    });
  }, { rootMargin: "0px 0px -12% 0px", threshold: 0.2 }) : null;
  function revelarItens(raiz) {
    (raiz || document).querySelectorAll(".revelar").forEach(function (el) {
      if (!obs) { el.classList.add("visivel"); return; }
      var vigia = el.parentElement || el;
      alvos.set(vigia, (alvos.get(vigia) || []).concat(el));
      obs.observe(vigia);
    });
  }
  // pulso dos botões: todos presos ao mesmo relógio da página, para pulsarem juntos
  function sincronizarPulso() {
    if (!document.getAnimations) return;
    document.getAnimations().forEach(function (a) {
      if (a.animationName === "pulso" || a.animationName === "pulso-anel") a.startTime = 0;
    });
  }
  function revelar(raiz) { revelarItens(raiz); sincronizarPulso(); }
  revelar();
  window.LMRevelar = revelar; // usado pela pré-visualização em arquivo único

  /* ---------- 3b. Banners da capa ---------- */
  var pararCarrossel = function () {};
  function iniciarCarrossel(capa) {
    if (!capa) return;
    pararCarrossel();
    var slides = capa.querySelectorAll(".capa__slide");
    var pontos = capa.querySelectorAll(".capa__ponto");
    var pausa = capa.querySelector(".capa__pausa");
    var atual = 0, timer = null, manual = false, foco = false;
    var TEMPO = 7000;

    var marcarPonto = function (i) {
      pontos.forEach(function (p) { p.removeAttribute("aria-current"); });
      void capa.offsetWidth; // reinicia a barra de progresso
      pontos[i].setAttribute("aria-current", "true");
    };
    var ir = function (n) {
      if (n === atual) return;
      slides[atual].classList.remove("ativo");
      atual = (n + slides.length) % slides.length;
      slides[atual].classList.add("ativo");
      marcarPonto(atual);
    };
    var parar = function () { clearTimeout(timer); timer = null; capa.classList.remove("rodando"); };
    // cada banner tem o seu tempo (o 1º, de apresentação, fica mais tempo na tela)
    var tempoDe = function (i) { return parseInt(slides[i].getAttribute("data-tempo"), 10) || TEMPO; };
    var rodar = function () {
      parar();
      if (manual || foco) return;
      timer = setTimeout(function () { ir((atual + 1) % slides.length); rodar(); }, tempoDe(atual));
      capa.classList.add("rodando");
      marcarPonto(atual);
    };
    var atualizarPausa = function () {
      capa.classList.toggle("pausado", manual);
      pausa.setAttribute("aria-label", manual ? "Retomar troca de banners" : "Pausar troca de banners");
    };

    pontos.forEach(function (p, i) { p.addEventListener("click", function () { ir(i); rodar(); }); });
    pausa.addEventListener("click", function () { manual = !manual; atualizarPausa(); rodar(); });
    // teclado: ao focar um link de outro banner, ele aparece; a troca para enquanto o foco estiver ali
    slides.forEach(function (s, i) {
      s.addEventListener("focusin", function () { foco = true; ir(i); parar(); });
    });
    capa.addEventListener("focusout", function (e) {
      if (!capa.querySelector(".capa__slides").contains(e.relatedTarget)) { foco = false; rodar(); }
    });

    // as fotos dos outros banners só carregam depois da página pronta
    var iniciar = function () {
      var comecar = function () {
        setTimeout(function () { capa.classList.add("pronto"); atualizarPausa(); rodar(); }, 400);
      };
      // com a abertura do logo, os banners só começam a trocar depois dela
      if (html.classList.contains("abrindo-trava")) document.addEventListener("lm:intro-fim", comecar, { once: true });
      else comecar();
    };
    pararCarrossel = parar;
    if (document.readyState === "complete") iniciar(); else window.addEventListener("load", iniciar);
  }
  iniciarCarrossel(document.querySelector(".capa"));
  window.LMCarrossel = iniciarCarrossel; // usado pela pré-visualização em arquivo único

  /* ---------- 3b2. Áreas da Início: cartões passando para o lado ---------- */
  var pararAreas = function () {};
  function iniciarAreas(raiz) {
    var c = (raiz || document).querySelector(".trilho-areas");
    if (!c) return;
    pararAreas();
    var lista = c.querySelector(".trilho__lista");
    var janela = c.querySelector(".trilho__janela");
    var cards = lista.children;
    var pausa = c.querySelector(".ca__pausa");
    var pos = 0, timer = null, manual = false, dentro = false;
    var TEMPO = (parseInt(c.getAttribute("data-tempo"), 10) || 5) * 1000;
    var porVez = function () { var w = window.innerWidth; return w >= 760 ? 3 : (w >= 560 ? 2 : 1); };
    var ultimo = function () { return Math.max(0, cards.length - porVez()); };
    var mostrar = function () {
      var passo = cards[1] ? cards[1].offsetLeft - cards[0].offsetLeft : 0;
      lista.style.transform = "translateX(" + (-pos * passo) + "px)";
      var n = porVez(), alto = 0;
      Array.prototype.forEach.call(cards, function (el, i) {
        var visivel = i >= pos && i < pos + n;
        if (visivel) { el.removeAttribute("inert"); alto = Math.max(alto, el.offsetHeight); } else el.setAttribute("inert", "");
      });
      // a altura acompanha só os cartões visíveis (sem vão branco embaixo)
      janela.style.height = alto + "px";
    };
    var ir = function (n) { var u = ultimo(); pos = n > u ? 0 : (n < 0 ? u : n); mostrar(); };
    var parar = function () { clearTimeout(timer); timer = null; };
    var rodar = function () { parar(); if (manual || dentro) return; timer = setTimeout(function () { ir(pos + 1); rodar(); }, TEMPO); };
    var atualizarPausa = function () {
      pausa.setAttribute("aria-pressed", String(manual));
      pausa.setAttribute("aria-label", manual ? "Retomar a troca automática" : "Pausar a troca automática");
      c.classList.toggle("pausado", manual);
    };
    c.querySelector(".ca__seta--ant").addEventListener("click", function () { ir(pos - 1); rodar(); });
    c.querySelector(".ca__seta--prox").addEventListener("click", function () { ir(pos + 1); rodar(); });
    pausa.addEventListener("click", function () { manual = !manual; atualizarPausa(); rodar(); });
    c.addEventListener("mouseenter", function () { dentro = true; parar(); });
    c.addEventListener("mouseleave", function () { dentro = false; rodar(); });
    c.addEventListener("focusin", function () { dentro = true; parar(); });
    c.addEventListener("focusout", function (e) { if (!c.contains(e.relatedTarget)) { dentro = false; rodar(); } });
    var x0 = null;
    c.addEventListener("touchstart", function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    c.addEventListener("touchend", function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0; x0 = null;
      if (Math.abs(dx) > 40) { ir(pos + (dx < 0 ? 1 : -1)); rodar(); }
    });
    window.addEventListener("resize", function () { if (pos > ultimo()) pos = ultimo(); mostrar(); });
    window.addEventListener("load", mostrar);
    mostrar();
    if ("IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (es) {
        es.forEach(function (en) { if (en.isIntersecting) rodar(); else parar(); });
      }, { threshold: 0.3 });
      io.observe(c);
      pararAreas = function () { parar(); io.disconnect(); };
    } else { rodar(); pararAreas = parar; }
    atualizarPausa();
  }
  iniciarAreas();
  window.LMAreas = iniciarAreas; // usado pela pré-visualização em arquivo único

  /* ---------- 3b3. Formulário de contato: validação e proteção contra robôs ----------
     Sem JavaScript, os limites do próprio HTML continuam valendo (maxlength, pattern, required).
     No servidor, a Netlify filtra spam (honeypot + filtro automático). */
  (function () {
    var form = document.querySelector('form[name="contato"]');
    if (!form) return;
    form.noValidate = true;
    var t0 = Date.now();
    var $ = function (id) { return document.getElementById(id); };
    var nome = $("nome"), tel = $("telefone"), assunto = $("assunto"), msg = $("mensagem"), ok = $("consentimento");
    var envioErro = $("envio-erro"), botao = form.querySelector('button[type="submit"]');
    var contador = form.querySelector(".contador");
    var DDD = "11 12 13 14 15 16 17 18 19 21 22 24 27 28 31 32 33 34 35 37 38 41 42 43 44 45 46 47 48 49 51 53 54 55 61 62 63 64 65 66 67 68 69 71 73 74 75 77 79 81 82 83 84 85 86 87 88 89 91 92 93 94 95 96 97 98 99".split(" ");
    var LIXO = /^(teste?|test|asdf\w*|qwer\w*|aaa+|abc|xxx+|nome|fulano|ciclano|admin|null|undefined)$/i;
    var limpa = function (v) { return v.replace(/\s+/g, " ").trim(); };
    var digitos = function (v) { return v.replace(/\D/g, ""); };

    // máscara do telefone: (55) 99999-9999
    tel.addEventListener("input", function () {
      var d = digitos(tel.value);
      if (d.length > 11 && d.indexOf("55") === 0) d = d.slice(2);
      d = d.slice(0, 11);
      var f = d;
      if (d.length > 2) f = "(" + d.slice(0, 2) + ") " + d.slice(2);
      if (d.length > 6) f = "(" + d.slice(0, 2) + ") " + d.slice(2, d.length - 4) + "-" + d.slice(d.length - 4);
      tel.value = f;
    });
    // nome: só letras, espaço, apóstrofo, ponto e hífen
    nome.addEventListener("input", function () {
      var v = nome.value.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ'’. \-]/g, "");
      if (v !== nome.value) nome.value = v;
    });
    var atualizarContador = function () { if (contador) contador.textContent = msg.value.length + "/800"; };
    msg.addEventListener("input", atualizarContador);

    var regras = {
      nome: function () {
        var v = limpa(nome.value);
        if (!v) return "Informe seu nome.";
        if (/[^A-Za-zÀ-ÖØ-öø-ÿ'’. \-]/.test(v)) return "Use só letras no nome.";
        var partes = v.split(" ").filter(function (p) { return p.replace(/[.'’\-]/g, "").length >= 2; });
        if (partes.length < 2) return "Informe nome e sobrenome.";
        if (v.length < 5 || v.length > 60) return "O nome deve ter entre 5 e 60 caracteres.";
        if (/(.)\1\1/i.test(v)) return "Confira o nome digitado.";
        for (var i = 0; i < partes.length; i++) {
          if (LIXO.test(partes[i])) return "Informe seu nome verdadeiro.";
          if (partes[i].length > 3 && !/[aeiouyáàâãéêíóôõúü]/i.test(partes[i])) return "Confira o nome digitado.";
        }
        return "";
      },
      telefone: function () {
        var d = digitos(tel.value);
        if (!d) return "Informe um telefone com DDD.";
        if (d.length !== 10 && d.length !== 11) return "O telefone deve ter DDD e 8 ou 9 dígitos.";
        if (DDD.indexOf(d.slice(0, 2)) < 0) return "Esse DDD não existe. Confira o número.";
        var n = d.slice(2);
        if (n.length === 9 && n[0] !== "9") return "Celular com 9 dígitos começa com 9.";
        if (n.length === 8 && !/[2-5]/.test(n[0])) return "Confira o número: telefone fixo começa com 2, 3, 4 ou 5.";
        if (/^(\d)\1+$/.test(n) || "0123456789".indexOf(n.slice(-8)) >= 0 || "9876543210".indexOf(n.slice(-8)) >= 0) return "Informe um número de telefone real.";
        return "";
      },
      assunto: function () { return assunto.value ? "" : "Escolha um assunto."; },
      mensagem: function () {
        var v = limpa(msg.value);
        if (v.length < 20) return "Escreva pelo menos 20 caracteres.";
        if (v.length > 800) return "A mensagem pode ter até 800 caracteres.";
        if (/<[^>]*>|[{}\[\]]{2,}/.test(v)) return "Não use códigos ou símbolos especiais.";
        if (/[^\s@]+@[^\s@]+\.[a-z]{2,}/i.test(v)) return "Não precisa informar e-mail: o retorno é pelo telefone.";
        if (/(https?:\/\/|www\.|\b[a-z0-9-]+\.(com|net|org|info|biz|xyz|ru|io|top|site|online|link)\b)/i.test(v)) return "Por segurança, não envie links.";
        if (/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/.test(v) || /(\d[ .-]?){13,19}/.test(v)) return "Não envie CPF, cartão ou outros números de documentos.";
        if (/(.)\1{5,}/.test(v)) return "Confira o texto digitado.";
        if ((v.match(/[A-Za-zÀ-ÿ]/g) || []).length < 15) return "Descreva o assunto com palavras.";
        return "";
      },
      consentimento: function () { return ok.checked ? "" : "Marque a concordância para enviar."; }
    };
    var campos = { nome: nome, telefone: tel, assunto: assunto, mensagem: msg, consentimento: ok };
    var validar = function (k) {
      var erro = regras[k](), el = campos[k], slot = $(k + "-erro");
      if (slot) slot.textContent = erro;
      if (erro) el.setAttribute("aria-invalid", "true"); else el.removeAttribute("aria-invalid");
      return !erro;
    };
    Object.keys(campos).forEach(function (k) {
      campos[k].addEventListener("blur", function () { if (campos[k].value || k === "consentimento") validar(k); });
      campos[k].addEventListener("change", function () { if (campos[k].getAttribute("aria-invalid")) validar(k); });
    });

    form.addEventListener("submit", function (e) {
      envioErro.textContent = "";
      var primeiro = null;
      Object.keys(campos).forEach(function (k) { if (!validar(k) && !primeiro) primeiro = campos[k]; });
      if (primeiro) { e.preventDefault(); primeiro.focus(); return; }
      // robô: preencheu o campo escondido ou enviou rápido demais
      var isca = form.querySelector('[name="campo-extra"]');
      if ((isca && isca.value) || Date.now() - t0 < 4000) { e.preventDefault(); envioErro.textContent = "Aguarde alguns segundos e envie novamente."; return; }
      // evita envios repetidos em sequência
      try {
        var ultimo = parseInt(localStorage.getItem("lm-contato-enviado") || "0", 10);
        if (Date.now() - ultimo < 120000) { e.preventDefault(); envioErro.textContent = "Sua mensagem já foi enviada há pouco. Se for urgente, use o WhatsApp."; return; }
        localStorage.setItem("lm-contato-enviado", String(Date.now()));
      } catch (err) { /* navegador sem armazenamento: segue */ }
      // envia o texto já limpo
      nome.value = limpa(nome.value); msg.value = limpa(msg.value);
      botao.disabled = true; botao.textContent = "Enviando…";
    });
  })();

  /* ---------- 3c. Filtro da lista de artigos ---------- */
  function iniciarFiltros(raiz) {
    var botoes = (raiz || document).querySelectorAll(".filtro");
    if (!botoes.length) return;
    var cards = (raiz || document).querySelectorAll(".artigo-card");
    botoes.forEach(function (b) {
      b.addEventListener("click", function () {
        var cat = b.getAttribute("data-cat");
        botoes.forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
        cards.forEach(function (c) { c.hidden = !!cat && c.getAttribute("data-cat") !== cat; });
      });
    });
  }
  iniciarFiltros();
  window.LMFiltros = iniciarFiltros;

  /* ---------- 4. Limpar parâmetros de rastreio ---------- */
  window.addEventListener("load", function () {
    try {
      var url = new URL(window.location.href);
      var mudou = false;
      Array.from(url.searchParams.keys()).forEach(function (k) {
        if (/^utm_/i.test(k) || k === "fbclid" || k === "gclid") { url.searchParams.delete(k); mudou = true; }
      });
      if (mudou) history.replaceState(history.state, "", url.pathname + (url.search || "") + url.hash);
    } catch (e) { /* navegador antigo: não faz nada */ }
  });
})();
